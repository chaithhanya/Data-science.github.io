# Prediction-using-Supervised-ML
Data Science and Business Analytics Task-1 (Predict the percentage of an student based on the no. of study hours)
Using simple linear regression model, forecasting the marks of a student based on the numbers of hours studied per day.
Tool(s) Used - Python (Jupyter Notebook)
